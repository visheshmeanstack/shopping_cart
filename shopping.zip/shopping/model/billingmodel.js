var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var billingschema = new Schema({
	name:String,
	email:String,
	phone:String,
	address:String,
	pin:String,
	payment:String,
	amount:String
});

var user = mongoose.model('billing',billingschema);
module.exports = user;