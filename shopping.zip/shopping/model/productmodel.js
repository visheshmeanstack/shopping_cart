var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var productmodel = new Schema({
	pname:String,
	pprice:String,
	file:String
})

var user = mongoose.model('user1',productmodel);
module.exports = user;
